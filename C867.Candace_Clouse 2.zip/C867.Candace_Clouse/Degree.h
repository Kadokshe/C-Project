#pragma once
#include<iostream>
#include<iomanip>
#include<cstring>

using std::string;

enum DegreeProgram { SECURITY, NETWORK, SOFTWARE, UNKNOWN };

static const string degreeProgramS[] = { "SECURITY", "NETWORK", "SOFTWARE","UNKNOWN" };

// This part of the project is to define the different degree programs listed in the rubric of assignment.
