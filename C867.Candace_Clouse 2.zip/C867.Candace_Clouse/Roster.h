#pragma once
#include <iostream>
#include <string>
#include "Student.h"









class Roster {
private:

    int lastIndex = -1;
    //const static int numStudents = 5;
    Student* classRosterArray[5];

public:
    
    
   
    
    
    
    
    
    
    void parse(string studentData);
    // parses to a string that is separated by commas for neat presentation
    
    void add(
             string stdtID,
             string fName,
             string lName,
             string emailAddy,
             int stdtAge,
             int daysInCourses1,
             int daysInCourses2,
             int daysInCourses3,
             DegreeProgram dp
             );
    void removeStudentbyIDnumber(string stdtID);
    
    //Print Functions
    void printAll();
    void printByDegreePrgm(DegreeProgram dp);
    void printInvalidEmails();
    void printAvgDaysInCourses(string stdtID);
    
    
    Student findStudent(int lastIndex);

    
   
    

    

    
~Roster();
    
	
};
