#pragma once
#include "Degree.h"
#include <string>

using namespace std;

class Student {
    
private:
    
    string stdtID;
    string fName;
    string lName;
    string emailAddy;
    int stdtAge;
    int daysArray[3];
    DegreeProgram degreeProgram;
    
public:
    Student();
    
    const static int daysArraySize = 3;
    
   
    
    Student(string stdtID, string fName, string lName, string emailAddy, int stdtAge, int* daysComplete, DegreeProgram type);
    
    // GETTERS
    
    string getStdtID();
    string getfName();
    string getlName();
    string getEmailAddy();
    int getStdtAge();
    int* getdaysInCourses();
    DegreeProgram getDegreePrgm();
    
    //SETTERS per rubric
    void setstdtID(string ID);
    void setFname(string fName);
    void setLname(string lName);
    void setEmailAddy(string emailAddy);
    void setStdtAge(int stdtAge);
    void setDaysInCourses(int* daysArray);
    void setDegreeProgram(DegreeProgram dT);
    
    ~Student();
    
    
    void print();
    
    
};



