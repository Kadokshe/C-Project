#include <iostream>
using namespace std;
#include "Roster.h"
#include <string>
using std::string;
using std::stoi;





void Roster::parse(string rowdata)
{
    
    DegreeProgram dp = UNKNOWN;
    if (rowdata.back() == 'Y')
    {dp = SECURITY;
    }
    else if (rowdata.back() == 'K')
    {dp = NETWORK;
    }
    else if (rowdata.back() == 'E')
    {dp = SOFTWARE;
    }
    else
    {
        cout << "DEGREE PROGRAM DATA IS NOT VALID/n";
        cout << degreeProgramS << "/n";
        //exit(-1);
    }
    
    if (lastIndex < numStudents)
    {
        
        lastIndex++;
        
        //Finding Student ID
        int rhs = rowdata.find(",");
        string stdtID = rowdata.substr(0, rhs);
        
        int lhs = rhs + 1;
        rhs = rowdata.find(",", lhs);
        string ftName = rowdata.substr(lhs, rhs - lhs);
        
        lhs = rhs + 1;
        rhs = rowdata.find(",", lhs);
        string ltName = rowdata.substr(lhs, rhs - lhs);
        
        lhs = rhs + 1;
        rhs = rowdata.find(",", lhs);
        string emailAddy = rowdata.substr(lhs, rhs - lhs);
        
        lhs = rhs + 1;
        rhs = rowdata.find(",", lhs);
        int stdtAge = stoi(rowdata.substr(lhs, rhs - lhs));
        
        
        lhs = rhs + 1;
        rhs = rowdata.find(",", lhs);
        string daysInCourses1 = rowdata.substr(lhs, rhs - lhs);
        int daysCourses1 = stoi(daysInCourses1);
        
        lhs = rhs + 1;
        rhs = rowdata.find(",", lhs);
        string daysInCourses2 = rowdata.substr(lhs, rhs - lhs);
        int daysCourses2 = stoi(daysInCourses2);
        
        lhs = rhs + 1;
        rhs = rowdata.find(",", lhs);
        string daysInCourses3 = rowdata.substr(lhs, rhs - lhs);
        int daysCourses3 = stoi(daysInCourses3);
        
        add(stdtID, ftName, ltName, emailAddy, stdtAge, daysCourses1, daysCourses2, daysCourses3, dp);
    }};

/*Student* s = new Student(stdtID, fName, lName, emailAddy, stdtAge, daysArray, dp);
classRosterArray[lastIndex++] = *s*/
void Roster::add
(string stdtID,
 string fName,
 string lName,
 string emailAddy,
 int stdtAge,
 int daysInCourses1,
 int daysInCourses2,
 int daysInCourses3,
 DegreeProgram dp)
{
    int daysArray[3] = { daysInCourses1, daysInCourses2, daysInCourses3};
}
    
        
    //    classRosterArray[lastIndex] = new Student(stdtID, fName, lName, emailAddy, stdtAge, daysArray, dp);
    

void Roster::printAll()
{
    
    for (int i = 0; i < Roster::lastIndex; i++)
    (
     this ->classRosterArray[i]->print()
     );
}

void Roster::printByDegreePrgm(DegreeProgram dp)
{
    cout << "\n\n";
}

void Roster::printInvalidEmails()
{
    bool any = false;
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        string emailAddy = (classRosterArray[i]->getEmailAddy());
        if (emailAddy.find(' ') != string::npos || emailAddy.find('.') == string::npos || emailAddy.find('@') == string::npos)
        {
            any = true;
            std::cout << emailAddy << ": " << classRosterArray[i]->getStdtID() << "\n";
        }
    }
    if (!any) cout << "NONE" << "\n";
}

void Roster::printAvgDaysInCourses(string stdtID)
{
    for (int i = 0; i <= Roster::lastIndex; i++) {
        if (stdtID == classRosterArray[i]->getStdtID()) {
            cout << (classRosterArray[i]->getdaysInCourses()[0]
                     + classRosterArray[i]->getdaysInCourses()[1]
                     + classRosterArray[i]->getdaysInCourses()[2]) / 3 << " is the average number of days left for " << stdtID << "\n";
        }
    }
    cout << "\n";
}

void Roster::removeStudentbyIDnumber(string stdtID)
{
    bool positive = false;
    for (int i = 0; i <= Roster::lastIndex; i++)
    {
        if (classRosterArray[i]->getStdtID() == stdtID)
        {
            positive = true;
            if (i < numStudents - 1)
            {
                Student tempspace = classRosterArray[i];
                classRosterArray[i] = classRosterArray[numStudents - 1];
                classRosterArray[numStudents - 1] = tempspace;
            }
            Roster::lastIndex--;
        }
    }
    if (positive)
    {
        std::cout << stdtID << " removed from roster." << "\n\n";
        this->printAll();
    }
    else std::cout << stdtID << " not found." << "\n\n";
}

Student Roster::findStudent(int lastIndex) {
    return classRosterArray[lastIndex];
}

Roster::~Roster()
{
  /*  std::cout << "Destructor initiated." << "\n\n";
    for (int i = 0; i < numStudents; i++)
    {
        std::cout << "Erasing student #" << i + 1 << "\n";
        delete classRosterArray[i];
        classRosterArray[i] = nullptr;
    }
    */
    std::cout << "Destructor initiated." << "\n\n";
           for (int i = 0; i < lastIndex; i++) {
                 delete classRosterArray[i];
           }
          // delete classRosterArray;
};

