#include <iostream>
#include "Roster.h"


using std::string;
using std::cout;
using namespace std;

int main()
{
    std::cout << "Course: Scripting and Programming Application C867\n";
    std::cout << "Programming Language Used: C++\n";
    std::cout << "Student ID:  #000866263 \n";
    std::cout << "Name: Candace Clouse\n\n";
    
    
    const int numStudents = 5;
    /*const*/ static string studentData[] =
    {
        "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
        "A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
        "A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
        "A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
        "A5,Candace,Clouse,cclous5@wgu.edu,30,49,24,30,SOFTWARE"
    };
    
    
    Roster* classRosterArray = new Roster();
    
    
    
    
    
    for (int i = 0; i < numStudents; i++) classRosterArray->parse(studentData[i]);
    cout << "All students in roster: " << "\n\n";
    classRosterArray->printAll();
    cout << "\n";
    
    
    for (int i = 0; i < numStudents; i++) {
        cout << "Displaying results by degree type: " << degreeProgramS[i] << "\n";
        classRosterArray->printByDegreePrgm((DegreeProgram)i);
    }
    
    cout << "Displaying student records with invalid email addresses" << "\n";
    classRosterArray->printInvalidEmails();
    cout << "\n";
    
    cout << "Displaying average days to complete courses: " << "\n";
    for (int i = 0; i < numStudents; i++) {
        Student s = classRosterArray->findStudent(i);
        classRosterArray->printAvgDaysInCourses(s.getStdtID());
    }
    cout << "\n";
    
    cout << "Removing student record 'A3':" << "\n";
    classRosterArray->removeStudentbyIDnumber("A3");
    cout << "\n";
    
    cout << "All students in roster: " << "\n";
    classRosterArray->printAll();
    cout << "\n\n";
    
    cout << "Removing student record 'A3':" << "\n";
    classRosterArray->removeStudentbyIDnumber("A3");
    cout << "\n";
    
    
    
    system("pause");
    
    
    
    
    
    
    return 0;
    
};
