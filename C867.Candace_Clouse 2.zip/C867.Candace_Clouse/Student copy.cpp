#include <iostream>
//#include <string>
#include "Student.h"
#include "Degree.h"
using std::string;

// Empty Constructor
Student::Student()
{
	this->stdtID = "";
	this->fName = "";
	this->lName = "";
	this->emailAddy = "";
	this->stdtAge = 0;
	this->daysArray[0] = 11;
	this->daysArray[1] = 22;
	this->daysArray[2] = 33;


	this->degreeProgram = DegreeProgram::UNKNOWN;
};

//Student::~Student() {}

//full constructor
Student::Student(string stdtID, string fName, string lName, string emailAddy, int stdtAge, int daysInTheCourses[], DegreeProgram type)
{
	this->stdtID = stdtID;
	this->fName = fName;
	this->lName = lName;
	this->emailAddy = emailAddy;
	this->stdtAge = stdtAge;
	this->daysArray = new int[daysArraySize];
	for (int i = 0; i < daysArraySize; i++)
		this->daysArray[i] = daysInTheCourses[i];
};

//Student::~Student() {}

//GETTERS

string Student::getStdtID() { 
	return this->stdtID; }
string Student::getfName() { 
	return this->fName; }
string Student::getlName() {
	return this->lName;
}

string Student::getEmailAddy() {
	return this->emailAddy;
}
int Student::getStdtAge() { return this->stdtAge; }
int* Student::getdaysInCourses() { return this->daysArray; }
DegreeProgram Student::getDegreePrgm() { return this->degreeProgram; }

//SETTERS
void Student::setstdtID(string ID)
{
	this->stdtID = ID;
}
void Student::setFname(string fName)
{
	this->fName = fName;
}
void Student::setLname(string lName)
{
	this->lName = lName;
}
void Student::setEmailAddy(std::string emailAddy)
{
	this->emailAddy = emailAddy;
}
void Student::setStdtAge(int stdtAge)
{
	this->stdtAge = stdtAge;
}
void Student::setDaysInCourses(int daysComplete[daysArraySize]) {
	for (int i = 0; i < daysArraySize; i++)

		this->daysArray[i] = daysComplete[i];
}

void Student::setDegreeProgram(DegreeProgram degreeProgram) {
	this->degreeProgram = degreeProgram;
}



//Print out the Roster
void Student::print() {
	cout << "Student ID#: "; 
		cout << this->getStdtID() << "\t";
	cout << "Full Name: ";
			cout << this->getfName() << "\t";
	cout << this->getlName() << "\t";
	cout << "Email Address: ";
	cout << this->getEmailAddy() << "\t";
	cout << "Student Age: ";
	cout << this->getStdtAge() << "\t";
	cout << "Days it took to complete courses: ";
	cout << this->getdaysInCourses()[0] << ",";
	cout << this->getdaysInCourses()[1] << ",";
	cout << this->getdaysInCourses()[2] << "\t";
	cout << "Degree Program: ";
	cout << degreeProgramS[this->getDegreePrgm()] << "\n";
}

Student::~Student()
{};
