//
//  main.cpp
//  C867.Candace_Clouse
//
//  Created by Nikki Clouse on 3/26/21.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
